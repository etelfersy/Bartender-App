﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EE_BartenderApp.Models
{
    public static class Order
    {
        private static List<CustomerOrder> orders = new List<CustomerOrder>();
        public static IEnumerable<CustomerOrder> Orders
        {
            get
            {
                return orders;
            }
        }
        public static void AddOrder(CustomerOrder order)
        {
            orders.Add(order);
        }
    }
}
