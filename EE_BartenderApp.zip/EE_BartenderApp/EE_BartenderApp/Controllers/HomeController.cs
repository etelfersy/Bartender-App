﻿using EE_BartenderApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace EE_BartenderApp.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }

        [HttpGet]
        public ViewResult OrderForm()
        {
            return View();
        }

        [HttpPost]
        public ViewResult OrderForm(CustomerOrder order)
        {
            Order.AddOrder(order);
            return View("OrderPlaced", order);
        }

        public ViewResult OrderQueue()
        {
            return View(Order.Orders);
        }
    }
}
